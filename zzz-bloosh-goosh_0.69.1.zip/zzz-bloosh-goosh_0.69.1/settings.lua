data:extend({
    {
        type = "bool-setting",
        name = "bloosh-goosh-util",
        setting_type = "startup",
        default_value = true
    },
})